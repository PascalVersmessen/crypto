package asymetric;

import java.security.KeyPair;

public class DigitalSignECDSA {
	
	public static KeyPair generateKeyPairECDSA() {
			
		return null;
	}

	public static void main (String[] args){
		try {
			generateKeyPairECDSA();	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
